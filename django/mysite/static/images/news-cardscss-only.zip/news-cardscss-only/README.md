# News Cards - CSS only

A Pen created on CodePen.io. Original URL: [https://codepen.io/choogoor/pen/YWBxrg](https://codepen.io/choogoor/pen/YWBxrg).

Pure CSS news cards with revealing content on hover. Please feel free to drop a comment with some suggestion for improvement. 